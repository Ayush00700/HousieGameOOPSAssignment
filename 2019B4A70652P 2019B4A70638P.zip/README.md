# HousieGameOOPSAssignment
Implementing Housie Game using concepts of Object Oriented Programming for OOP Assignment

Group Members: 
1)Ayush Agarwal(2019B4A70652P)
2) Yash Goyal(2019B4A70638P)
Project Number: 11
Project Title: Implementing Housie Game

Description of Code Submitted:
To run the Code, Copy all the.java files to the root directory and run the following commands on terminal.

javac Moderator.java
java Moderator

Constraints: 
Each Player can win atmost one prize.
Moderator randomly chooses 3 or 4 or all 5 prizes out of the available 5 prizes.
Implementation of Multithreading is still pending and will be updated in the next submission.
Implementation of GUI is still pending and will be updated in the next submission.